Action()
{

	lr_start_transaction("open_site");

	return 0;
}